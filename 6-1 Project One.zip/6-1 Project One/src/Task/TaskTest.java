package Task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {
	@Test
	public void testTaskCreation() {
		Task task = new Task("12345", "Sample Task", "This is a sample description.");
		assertEquals("12345", task.getTaskId());
		assertEquals("Sample Task", task.getName());
		assertEquals("This is a sample description.", task.getDescription());
	}
	
	@Test
	public void testInvaildTaskId() {
		assertThrows(IllegalArgumentException.class, () -> new Task(null, "Sample Task", "Description"));
		assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Sample Task", "Description"));
	}
	
	@Test
	public void testInvaildName() {
		assertThrows(IllegalArgumentException.class, () -> new Task("12345", null, "Description"));
		assertThrows(IllegalArgumentException.class, () -> new Task("12345", "ThisNameIsWayTooLongForValidation", "Description"));
	}
	
	@Test
	public void testInvaildDescription() {
		assertThrows(IllegalArgumentException.class, () -> new Task("12345", "Task", null));
		assertThrows(IllegalArgumentException.class, () -> new Task("12345", "Task", "This description is way too long to be accepted by the validation rules."));
	}
}