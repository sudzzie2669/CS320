package Task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
	private TaskService taskService;
	
	@BeforeEach
	public void setUp() {
		taskService = new TaskService();
	}
	
	@Test
	public void taskAddTask() {
		Task task = new Task("12345", "Task 1", "Description 1");
		taskService.addTask(task);
		assertEquals(task, taskService.getTask("12345"));
	}
	
	@Test
	public void testAddDuplicateTask() {
		Task task = new Task("12345", "Task 1", "Description 1");
		taskService.addTask(task);
		assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task));
	}
	
	@Test
	public void taskDeleteTask() {
		Task task = new Task("12345", "Task 1", "Description 1");
		taskService.addTask(task);
		taskService.deleteTask("12345");
		assertNull(taskService.getTask("12345"));
	}
	
	@Test
	public void testUpdateTaskName() {
		Task task = new Task("12345", "Task 1", "Description 1");
		taskService.addTask(task);
		taskService.updateTaskName("12345", "Updated Task");
		assertEquals("Updated Task", taskService.getTask("12345").getName());
	}
	
	@Test
	public void testUpadteTaskDescription() {
		Task task = new Task("12345", "Task 1", "Description 1");
		taskService.addTask(task);
		taskService.updateTaskDescrpition("12345", "Updated Description");
		assertEquals("Updated Description", taskService.getTask("12345").getDescription());
	}

}
	
	