package Appointment;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {
	
	@Test
	public void testValidAppointmentCreation() {
		Date futureDate = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(futureDate);
		calendar.add(Calendar.DATE, 1);
		
		Appointment appointment = new Appointment("12345", calendar.getTime(), "Valid description");
		
		assertEquals("12345", appointment.getAppointmentId());
		assertEquals("Valid description", appointment.getDecription());
		assertTrue(appointment.getAppointmentDate().after(new Date()));
	}
	
	@Test
	public void testInvaildAppointmentId() {
		Date futureDate = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(futureDate);
		calendar.add(Calendar.DATE, 1);
		
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, calendar.getTime(), "Valid description");
		});
		
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345678901", calendar.getTime(), "Valid description");
		});
	}
	
	@Test
	public void testInvalidAppointmentDate() {
		Date pastDate = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(pastDate);
		calendar.add(Calendar.DATE, -1);
		
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345", calendar.getTime(), "Valid description");
		});
	}
	
	@Test
	public void testInvaildAppointmentDescription() {
		Date futureDate = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(futureDate);
		calendar.add(Calendar.DATE, 1);
		
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345", calendar.getTime(), null);
		});
		
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345", calendar.getTime(), "This description is way too long and exceeds fifty characters!");
		});
	}

}
