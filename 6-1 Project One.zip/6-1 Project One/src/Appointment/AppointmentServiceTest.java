package Appointment;

import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {
	
	@Test
	public void testAddAppointment() {
		AppointmentService service = new AppointmentService();
		
		Date futureDate = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(futureDate);
		calendar.add(Calendar.DATE, 1);
		
		Appointment appointment = new Appointment("12345", calendar.getTime(), "Valid description");
		service.addAppointment(appointment);
		
		assertEquals(appointment, service.getAppointment("12345"));
	}
	
	@Test
	public void testAddDuplicateAppointment() {
		AppointmentService service = new AppointmentService();
		
		Date futureDate = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(futureDate);
		calendar.add(Calendar.DATE, 1);
		
		Appointment appointment = new Appointment("12345", calendar.getTime(), "Valid description");
		service.addAppointment(appointment);
		
		assertThrows(IllegalArgumentException.class, () -> {
			service.addAppointment(appointment);
		});
	}
	
	@Test
	public void testDeleteAppointment() {
		AppointmentService service = new AppointmentService();
		
		Date futureDate = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(futureDate);
		calendar.add(Calendar.DATE, 1);
		
		Appointment appointment = new Appointment("12345", calendar.getTime(), "Valid description");
		service.addAppointment(appointment);
		
		service.deleteAppointment("12345");
		
		assertNull(service.getAppointment("12345"));
	}
	
	@Test
	public void testDeleteNonexistentAppointment() {
		AppointmentService service = new AppointmentService();
		
		assertThrows(IllegalArgumentException.class, () -> {
			service.deleteAppointment("99999");
		});
	}

}
