package Contact;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
	
	private ContactService contactService;
	
	@BeforeEach
	public void setUp() {
		contactService = new ContactService();
	}
	
	@Test
	public void testAddContact() {
		Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
		contactService.addContact(contact);
		assertEquals(contact, contactService.getContact("123"));
	}
	
	@Test
	public void testAddDuplicateContactId() {
		Contact contact1 = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
		Contact contact2 = new Contact("123", "Jane", "Doe", "0987654321", "456 Elm St");
		contactService.addContact(contact1);
		assertThrows(IllegalArgumentException.class, () -> contactService.addContact(contact2));
	}
	
	@Test
	public void testDeleteContact() {
		Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
		contactService.addContact(contact);
		contactService.deleteContact("123");
		assertThrows(IllegalArgumentException.class, () -> contactService.getContact("123"));
	}
	
	@Test
	public void testUpdateContact() {
		Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
		contactService.addContact(contact);
		contactService.updateContact("123", "Jane", "Smith", "0987654321", "456 Elm St");
		
		Contact updatedContact = contactService.getContact("123");
		assertEquals("Jane", updatedContact.getFirstName());
		assertEquals("Smith", updatedContact.getLastName());
		assertEquals("0987654321", updatedContact.getPhone());
		assertEquals("456 Elm St", updatedContact.getAddress());
	}
	
	@Test
	public void testUpdateNonExistentContact() {
		assertThrows(IllegalArgumentException.class, () -> {
			contactService.updateContact("999", "Jane", "Doe", "0987654321", "456 Elm St");
		});
	}

}
